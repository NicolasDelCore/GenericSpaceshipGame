﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mapBorders : MonoBehaviour
{
	void OnTriggerEnter2D(Collider2D trigger)
	{
		//Debug.Log("Game object: " + trigger);
		//Debug.Log("Transform: " + trigger);
			if(trigger != (trigger.name == "enemyVision") && trigger != (trigger.name == "enemy-bullet(Clone)") && trigger != (trigger.name == "player-bullet(Clone)") && trigger != (trigger.name == "EnemyZone") && trigger != (trigger.name == "PlayerLastPos")) // this is so that the enemyVision trigger box is ignored, otherwise enemies would get trapped in a TP loop since the trigger box is too big, it also ignores player&enemy bullets, EnemyZone and playerLastPos
			{
				if(gameObject.name == "map-border-up")
				{
					trigger.transform.position = new Vector3 (trigger.transform.position.x, -50, trigger.transform.position.z); // teleport to -50 on the Y axis
				}
				if(gameObject.name == "map-border-down")
				{
					trigger.transform.position = new Vector3 (trigger.transform.position.x, 50, trigger.transform.position.z); // teleport to 50 on the Y axis
				}
				if(gameObject.name == "map-border-right")
				{
					trigger.transform.position = new Vector3 (-50, trigger.transform.position.y, trigger.transform.position.z); // teleport to -50 on the X axis
				}
				if(gameObject.name == "map-border-left")
				{
					trigger.transform.position = new Vector3 (50, trigger.transform.position.y, trigger.transform.position.z); // teleport to 50 on the X axis
				}
				
				if(trigger.tag == "enemy") // on Border's trigger entry, if otherObjGO has the "enemy" tag
				{
					//Debug.Log("Enemy has entered map borders" + otherObjGO.name);
					trigger.GetComponent<enemyIA>().teleporting = true; // we set the enemy.teleporting bool to true in the EnemyIA script - this corrects playerLastPos position when it is within the trigger (because EnemyIA interacts the findingPlayerLastPos script) and avoids a visual bug where the ship points to the wrong place during warping
				}
				if(trigger.tag == "player") // on Border's trigger entry, if otherObjGO has the "player" tag
				{
					trigger.GetComponent<playerMovement>().teleporting = true;
					//Debug.Log("Player has entered map borders " + trigger.name);
				}
			}
	}

	void OnTriggerExit2D(Collider2D trigger) // The functions of OnTriggerExit are sometimes skipped, thus all of this is being passed to the Update method using the alreadyTeleported flag
	{
		if(trigger != (trigger.name == "enemyVision") && trigger != (trigger.name == "enemy-bullet(Clone)") && trigger != (trigger.name == "player-bullet(Clone)") && trigger != (trigger.name == "EnemyZone") && trigger != (trigger.name == "PlayerLastPos")) 
			if (trigger == (trigger.tag == "enemy"))
			{
				trigger.GetComponent<enemyIA>().teleporting = false; // we set the enemy.teleporting bool back to false, so that the enemy recovers movement
				//Debug.Log("Enemy has exited map borders " + otherObjGO.name);
			}
			if(trigger.tag == "player") // on Border's trigger entry, if otherObjGO has the "player" tag
			{
				trigger.GetComponent<playerMovement>().teleporting = false;
				//Debug.Log("Player has exited map borders " + trigger.name);
			}
	}
}