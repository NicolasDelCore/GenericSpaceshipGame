﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyBullet : MonoBehaviour
{
	public GameObject enemyHitEffect; // particle effect for bullet destruction
	//bullet objects will destroy themselves with collisions, OR, after 1 seconds if nothing was hitted (using the timer bulletExpirationTimer)
	float enemyBulletExpirationTimer = 0f; //bulletExpirationTimer starts at 0
	
	void OnCollisionEnter2D(Collision2D collision)
	{
		//GameObject otherObj = collision.gameObject; // bullet collision debug, first line
		//Debug.Log("Collided with: " + otherObj); // bullet collision debug, second line
		GameObject effect = Instantiate(enemyHitEffect, transform.position, Quaternion.identity);
		Destroy(effect, 0.1f);
		Destroy(gameObject);
	}
	
	void Update()
	{
		enemyBulletExpirationTimer += Time.deltaTime; //add time to bulletExpirationTimer
		if (enemyBulletExpirationTimer >= 1) //if bulletExpirationTimer is greater or equal to 1 sec
		{
			enemyBulletExpires(); // call function bulletExpires
		}
	}
	
	void enemyBulletExpires(){
		GameObject effect = Instantiate(enemyHitEffect, transform.position, Quaternion.identity);
		Destroy(effect, 0.1f);
		Destroy(gameObject);
	}
	
}