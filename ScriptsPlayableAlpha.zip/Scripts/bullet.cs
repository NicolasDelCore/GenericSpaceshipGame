﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class bullet : MonoBehaviour
{
	public GameObject hitEffect; // particle effect for bullet destruction
	//bullet objects will destroy themselves with collisions, OR, after 1 seconds if nothing was hitted (using the timer bulletExpirationTimer)
	float bulletExpirationTimer = 0f; //bulletExpirationTimer starts at 0
	
	void OnCollisionEnter2D(Collision2D collision)
	{
		//GameObject otherObj = collision.gameObject; // bullet collision debug, first line
		//Debug.Log("Collided with: " + otherObj); // bullet collision debug, second line
		GameObject effect = Instantiate(hitEffect, transform.position, Quaternion.identity);
		Destroy(effect, 0.1f);
		Destroy(gameObject);
	}
	
	void Update()
	{
		bulletExpirationTimer += Time.deltaTime; //add time to bulletExpirationTimer
		if (bulletExpirationTimer >= 1) //if bulletExpirationTimer is greater or equal to 1 sec
		{
			bulletExpires(); // call function bulletExpires
		}
	}
	
	void bulletExpires(){
		GameObject effect = Instantiate(hitEffect, transform.position, Quaternion.identity);
		Destroy(effect, 0.1f);
		Destroy(gameObject);
	}
		
}