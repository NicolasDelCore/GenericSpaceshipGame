﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class timeScript : MonoBehaviour
{
	float timer; // in-game timer
	public Text timeNumber; // GUI timer
	
    // Start is called before the first frame update
    void Start()
    {
        //timer = timer + 3595; // testing the minutes-to-hours jump
		//timer = timer + 7190; // testing the two-hours jump
    }

    // Update is called once per frame
    void Update()
    {
		if(pauseMenu.gameIsPaused == false) // if the game is not paused
		{
		timer = timer + Time.deltaTime; // adds Time.deltaTime to the timer (time passed since last frame)
		string hours = Mathf.Floor(timer / 3600).ToString("00"); // calculate hours and transform the value to string with format hh
		string minutes = Mathf.Floor((timer / 60)%60).ToString("00"); // calculate and transform the value to string minutes with format mm
		string seconds = Mathf.Floor(timer % 60).ToString("00"); // calculate seconds and transform the value to string with format ss
		string milliseconds = Mathf.Floor((timer *1000)%1000).ToString("000"); // calculate milliseconds and transform the value to string with format mmm
		//Debug.Log(hours+":"+minutes+":"+seconds+"."+milliseconds); // line for debugging the clock
		timeNumber.text = (hours+":"+minutes+":"+seconds+"."+milliseconds); // timeNumber, which is responsible for updating the timer in the GUI
		}
    }
}
