﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class pauseMenu : MonoBehaviour
{
    public static bool gameIsPaused = false;
	
	public GameObject pauseMenuUI;
	public GameObject deathScreenUI;
	public GameObject player; // used for tracking life & showing the dead scren if life = 0
	public bool isPlayerAlive = true; // playerMovement script will update this value to "False" if player dies

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Escape))
		{
			if(gameIsPaused)
			{
				Resume();
			}
			else
			{
				Pause();
			}
		}
		
		if(isPlayerAlive == false) // if player dies, the isPlayerAlive bool gets updated by the playerMovement script, and we call the PlayerDead() function
		{
			PlayerDead();
		}
    }
	
	public void Resume ()
	{
		pauseMenuUI.SetActive(false);
		Time.timeScale = 1f;
		gameIsPaused = false;
	}
	
	void Pause ()
	{
		pauseMenuUI.SetActive(true);
		Time.timeScale = 0f;
		gameIsPaused = true;
	}
	
	public void LoadMenu()
	{
		gameIsPaused = false;
		isPlayerAlive = true;
		Time.timeScale = 1f;
		SceneManager.LoadScene("mainMenu");
	}
	
	public void QuitGame()
	{
		Application.Quit();
	}
	
	public void PlayerDead()
	{
		deathScreenUI.SetActive(true);
		Time.timeScale = 0f;
		gameIsPaused = true;
	}
	
		public void Restart()
	{
		gameIsPaused = false;
		isPlayerAlive = true;
		Time.timeScale = 1f;
		SceneManager.LoadScene("infiniteLevel");
	}
}
