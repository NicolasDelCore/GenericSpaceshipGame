﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// this script handles the score system

public class scoreScript : MonoBehaviour
{
	//score vars
	public int score; // score int, it's updated from the enemyIA script - each time an enemy dies = +100 points
	public Text scoreNumber; // score number text
	
	
    void Update()
    {
		//Debug.Log("Score: " + score);
		scoreNumber.text = score.ToString(); // updates the score text to match the score int		
    }
}