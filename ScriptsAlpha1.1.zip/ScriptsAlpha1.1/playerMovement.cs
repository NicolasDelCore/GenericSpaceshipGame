using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//script from https://www.youtube.com/watch?v=LNLVOjbrQj4&ab_channel=Brackeys

public class playerMovement : MonoBehaviour
{
	public float moveSpeed = 20f;
	public Rigidbody2D rb;
	public Camera cam;
	Vector2 movement;
	Vector2 mousePos;
	public bool teleporting = false; // this is a flag to fix a visual bug: during teleportation from one map border to the other, the ship looks to the wrong place for a fraction of a second due to its rotation pointing to the mouse, to fix this, we disable this rotation by changing the teleporting bool to true in CollisionEnter, then we change it to false again in the CollisionExit so that rotation is recovered
	public bool isPlayerAlive = true;
	public float life = 100f;
	public float shipSpeed;
	public GameObject deadEffect;
	public GameObject lifeNumber;
	public GameObject pauseMenu;
	public GameObject horizCam; // border cam horiz 
	public GameObject vertCam; // // border cam vert	
	//public GameObject reflectHorizCam; // border ref horiz 
	//public GameObject reflectVertCam; // border ref vert
	//public GameObject playerSafeZone; // trigger attached to the player; if the enemy enters it, the playerLastPos will be equal to the enemy pos, this is so that the enemy doesn't pushes the player forever and stops a few centimeters away from it
	
	void Start()
	{
	lifeNumber.GetComponent<lifeScript>().life = life; // we update the life value in the GUI
	}
	
	//Update is called once per frame, used to get input
	void Update()
	{
			
	movement.x = Input.GetAxisRaw("Horizontal"); // X axis movement
	movement.y = Input.GetAxisRaw("Vertical");	// Y axis movement	
	mousePos = cam.ScreenToWorldPoint(Input.mousePosition); // ship pointing to mouse
	
	//player teleport debug
	//if(teleporting == true)
	//{
	//	Debug.Log("Teleporting player");
	//}
	
	/*
	// movement
	*/
	
	//speed monitor
	//shipSpeed = rb.velocity.magnitude; // no longer using forces to move the player
	
	//update player life/dead
		if (life <= 0)
		{
			//Debug.Log("Enemy Destroyed");
			horizCam.GetComponent<horizCamPlayerFollow>().isPlayerAlive = false; // border cam horiz to stop following
			vertCam.GetComponent<vertCamPlayerFollow>().isPlayerAlive = false; // border cam vert to stop following
			Destroy(gameObject);
			GameObject effect = Instantiate(deadEffect, transform.position, Quaternion.identity); // dead effect particle
			Destroy(effect, 0.8f);
			pauseMenu.GetComponent<pauseMenu>().isPlayerAlive = false; // this shows the death screen
		}
	
	}
	
	//FixedUpdate used to actually move the character	
	void FixedUpdate()
	{
		if (teleporting == false) {
		rb.MovePosition(rb.position + movement * moveSpeed * Time.fixedDeltaTime); //movement
		//space-ship player points to the mouse
		Vector2 lookDir = mousePos - rb.position;
		float angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg - 90f;
		rb.rotation = angle;
		}
	}
	
	//taking damage from enemy-bullet
	void OnCollisionEnter2D(Collision2D collision)
	{
		if (collision.gameObject.name == "enemy-bullet(Clone)") // if the player is hitted by an enemy-bullet (which will be a clone of the enemy-bullet prefab), player takes damage
			{
				life = life - 10; // -10 life per shot
				lifeNumber.GetComponent<lifeScript>().life = life; // we update the life value in the GUI
				//Debug.Log("Life: " + life);
				//GameObject otherObj = collision.gameObject; // bullet collision debug, first line
				//Debug.Log("Collided with: " + otherObj); // bullet collision debug, second line
			}
	}
}