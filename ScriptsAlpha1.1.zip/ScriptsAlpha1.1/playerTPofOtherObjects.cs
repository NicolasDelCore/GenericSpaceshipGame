﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerTPofOtherObjects : MonoBehaviour
{
	Collider2D m_Collider;
	public GameObject player;
	public bool teleportingZone;
	public bool hasPlayerTeleported;
	public bool usedMapBorderUp;
	public bool usedMapBorderDown;
	public bool usedMapBorderRight;
	public bool usedMapBorderLeft;
	public Vector3 dist;
	
    void Start()
    {
        //Fetch the Collider from the GameObject this script is attached to
        m_Collider = GetComponent<Collider2D>();
	}
	
	void OnTriggerExit2D(Collider2D triggerTPofOtherObjects) // if something leaves the trigger area that surrounds the player's camera area
	{
		if (triggerTPofOtherObjects != (triggerTPofOtherObjects.name == "spaceship-player") && (triggerTPofOtherObjects != (triggerTPofOtherObjects.tag == "mapBorders")) &&(triggerTPofOtherObjects != (triggerTPofOtherObjects.name == "enemyVision")) && (triggerTPofOtherObjects != (triggerTPofOtherObjects.name == "EnemyZone")) && (triggerTPofOtherObjects != (triggerTPofOtherObjects.name == "PlayerLastPos")) && (triggerTPofOtherObjects != (triggerTPofOtherObjects.name == "FollowUpPos"))) //if (triggerTPofOtherObjects != (triggerTPofOtherObjects.name == "spaceship-player") && (triggerTPofOtherObjects != (triggerTPofOtherObjects.tag == "mapBorders")))
		{
			if (hasPlayerTeleported == true)
			{
				//map borders will update the bool value to indicate which one the player used
				if (usedMapBorderUp == true) //if map border up tp == true
				{
				usedMapBorderUp = false; //return the tp value of the map border to false so that it can be used again
				//tp enemy near to posplayer1 
				}
			}
			//get player-othergameobject distance before teleport-transition
			//teleport player
			//apply teleport to enemy + player-othergameobject distance
			//so if player tp is +50 X, enemy tp is enemy position = +50 X + (player-othergameobject dist)
			//OR maybe simpler: if player tps, player pos will be + 50 X, then just add 50x to enemy pos??
			//maybe force the TP from the mapborders script interacting with this script's collider2D trigger
			
			//Debug.Log(triggerTPofOtherObjects.name +" "+triggerTPofOtherObjects.transform.position);
			//if (m_Collider.bounds.Contains(triggerTPofOtherObjects.transform.position))
			//{
				//Debug.Log(triggerTPofOtherObjects.name +" "+triggerTPofOtherObjects.transform.position);
				//if (player.GetComponent<playerMovement>().teleporting == true)
				//{
					//hasPlayerTeleported = true;
					//if (hasPlayerTeleported == true)
					//{
						//dist = (triggerTPofOtherObjects.transform.position - player.transform.position).normalized + player.transform.position;
						//triggerTPofOtherObjects.transform.position = dist;
						//triggerTPofOtherObjects.transform.position = (triggerTPofOtherObjects.transform.position - player.transform.position).normalized * 11f + player.transform.position; // this line keeps the distance between the player and whatever object is in this zone, when the player teleports, the object teleports behind keeping the same distance it had, so the teleport-transition should be seamless and avoid enemies popping in/out of existance
						//hasPlayerTeleported = false;
						//Debug.Log("Teleporting "+triggerTPofOtherObjects.name);
					//}
				//}
			//}
		}
	}
	
	
	void Update()
	{
		Vector3 playerPosition = player.transform.position; // getting player V3 position and storing it into a new V3 variable called "playerPosition"
		transform.position = new Vector3 (playerPosition.x, playerPosition.y, transform.position.z); // instructions to follow the player on X and Y, keep Z as is
		hasPlayerTeleported = player.GetComponent<playerMovement>().teleporting; // check if player teleported (in Update method, that way is faster than having this check within the OnTrigger event)
	}
	
	// if (triggerTPofOtherObjects == (triggerTPofOtherObjects.name == "map-border-up"))
	//  if triggerTPofOtherObjects.tag != map borders
	//    triggerTPofOtherObjects.transform.position == mismas coordenadas que map borders
}