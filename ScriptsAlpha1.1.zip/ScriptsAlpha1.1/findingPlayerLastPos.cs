﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class findingPlayerLastPos : MonoBehaviour
{
	
	// this script interacts with the enemyIA script
	// this script is meant to be assigned to the playerLastPos game-object, which serves only as a pointer to where the enemy is suppoused to go when following the player
	// since we're using Pathfinder to trace the route the enemy should follow, it's necessary to setup a new gameObject (playerLastPos) with this script (findingPlayerLastPos) so that the enemy's Pathfinder can follow the player's last known position, rather than the real player position

	public bool isEnemyAlive; // bool to confirm if enemy is alive or not; if dead, findingPlayerLastPos will stop updating its position and self-destroy
	public bool playerFoundFlag; // bool used to verify if the player is lost or found
	public bool followUpFlag; // bool used to verify the followUp flag
	public bool secondFollowUpFlag = false; // bool used to activate follow up when player is out of sight
	public bool hasPlayerTeleportedPos; // stores the value of hasPlayerTeleported from the enemyIA script
	public bool teleportingFlag; // bool used to verify the followUp flag
	public bool inEnemyZoneFlag; // bool used to verify the inEnemyZone flag
	public bool reverseFollowUpBool; // inverse value of the followUp object 
	public Vector2 lastPlayerPosPathFinder; // last known position from player, saved as a Vector2
	public Vector2 enemyBodyPos; // Vector 2 with the enemy position
	public Transform enemyBody; // transform object that provides the info that the enemyBodyPos vector 2 needs
	public Transform followUp; // the distance the enemy will follow up moving after loosing the player
	public Transform reverseFollowUp; //
	public GameObject enemyObject; // reference to the enemy game-object so that we can access some variables (playerFound, lastPlayerPos and followUp bools)

    // Start is called before the first frame update
    void Start()
    {
		lastPlayerPosPathFinder = gameObject.transform.position; // playerLastPos object is created with the enemy, so at start, it takes the value of the enemy position so the enemy remains quiet on spawn.
		transform.SetParent(null); //  We unparent the playerLastPos-child from the enemy-parent at the start, this prevents the playerLastPost transform from being updated by the parent's transform (thus making the parent move forward forever after the player is lost).
		isEnemyAlive = true; // We confirm if the enemy object is alive or not, this way: we execute code if it's alive, or if it's dead, we destroy this playerLastPos game-object
	}

    // Update is called once per frame
    void Update()
    {			
			if (isEnemyAlive == true) // isEnemyAlive check, if so:
			{
				enemyBodyPos.x = enemyBody.position.x; // we get X axis from enemy object
				enemyBodyPos.y = enemyBody.position.y; // we get Y axis from enemy object
				playerFoundFlag = enemyObject.GetComponent<enemyIA>().playerFound; // we get&update the playerFound value from the enemy object
				followUpFlag = enemyObject.GetComponent<enemyIA>().followUp;
				teleportingFlag = enemyObject.GetComponent<enemyIA>().teleporting;
				inEnemyZoneFlag = enemyObject.GetComponent<enemyIA>().inEnemyZone;
				hasPlayerTeleportedPos = enemyObject.GetComponent<enemyIA>().hasPlayerTeleported; // updates the hasPlayerTeleportedPos with the value hasPlayerTeleported from the enemyIA script
				
				if(playerFoundFlag == true) // if the player is found:
				{
					lastPlayerPosPathFinder = enemyObject.GetComponent<enemyIA>().lastPlayerPos; // we get the last player position registered by the enemyIA script
					transform.position = lastPlayerPosPathFinder; // we move this object to that position.
				}
				
				if(followUpFlag == true) // check the followUp flag in the enemyIA script, if true:
				{
					//ApproxVector = enemyBodyPos - lastPlayerPosPathFinder;
					//Debug.Log("enemyBodyPos " + enemyBodyPos);
					//Debug.Log("lastPlayerPosPathFinder " + lastPlayerPosPathFinder);
					//Debug.Log("ApproxVectorY " + ApproxVector);
					// check if the enemy is in the same position as the playerLastPos object, if it is:
					{
						//enemyObject.GetComponent<enemyIA>().followUp = false; // we set the followUp flag to false within the enemyIA script, and then
						//Debug.Log("enemy follow up flag should be off now");
						enemyObject.GetComponent<enemyIA>().followUp = false; // follow up back to false
						secondFollowUpFlag = true; // this flag is true for the ontriggerenter2d event
						//transform.position = followUp.transform.position; // we transform the position of the playerLastPos object to the position of the followUp game-object, which serves to extend the distance traveled by the enemy ship when loosing the player (the idea here is that if the enemy spotted the player at XY, it'll travel there, and if the player isn't there, it'll travel a little bit further in order to try to find the player)
					}
				}
				// teleporting flag update
				if (teleportingFlag == true) // Check to see if the enemy's teleport flag is true or not. If it is, the playerLastPos GO will be updated to the enemy's location. This prevents the playerLastPos GameObject from getting "stuck" in the teleporting map-borders (forcing the enemy to always travel the same path from border to border in an effort to reach the playerLastPos coordinates).
				{
					//PositionFixer();
					//Debug.Log("playerLastPos teleport");
					transform.position = followUp.transform.position;
				}
				if(inEnemyZoneFlag == true)
				{
					if (hasPlayerTeleportedPos == false) // if the player teleported, this flag will be true and thus the PlayerLastPos position won't be updated, allowing the enemy to chase the player through the portals (the map's borders), otherwise, if the player is too close (within the enemyZone trigger), the enemy will stop moving and maintain its distance from the player
					{
					transform.position = enemyBodyPos;
					}
				}
				if (hasPlayerTeleportedPos == true) // if hasPlayerTeleportedPos is true
				{
					transform.position = followUp.transform.position; // follow up
					enemyObject.GetComponent<enemyIA>().hasPlayerTeleported = false; // hasPlayerTeleportedPos back to false in the enemyIA script
					hasPlayerTeleportedPos = false; // hasPlayerTeleportedPos back to false in this script, otherwise it'll remain true here until the next Update cicle happens
				}
				
				//reverseFollowUp
				if (reverseFollowUpBool == true)
				{
					transform.position = reverseFollowUp.transform.position;
					reverseFollowUpBool = false; // disable the reverseFollowUp flag
				}
				
			}
			
			if (isEnemyAlive == false) // if the enemy gameObject is destroyed (when its life reaches 0 or less), before destroying itself it'll update the isEnemyAlive bool of this script, setting it to false
			{
				Destroy(gameObject); // this PlayerLastPos object self destroys, so it stops asking for the enemy position & enemy transform component forever
				//Debug.Log("PlayerLastPos destroyed");
			}
		}
	void OnTriggerEnter2D(Collider2D playerLastPosCollider)
		{
			if (secondFollowUpFlag == true)
			{
				//PositionFixer();
				//Debug.Log("enemy follow up flag should be off now");
				secondFollowUpFlag = false;
				transform.position = followUp.transform.position;
				//Debug.Log ("Fixing position: " + " || enemy: " + enemyBodyPos + " || Player last pos: " + transform.position + " || PlayerPos Vector 2: " + lastPlayerPosPathFinder);
				enemyObject.GetComponent<enemyIA>().hasPlayerTeleported = false;
			}
		}
}
