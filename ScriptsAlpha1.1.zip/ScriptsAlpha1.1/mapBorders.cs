﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class mapBorders : MonoBehaviour
{
	void OnTriggerEnter2D(Collider2D trigger)
	{
		//Debug.Log("Game object: " + trigger);
		//Debug.Log("Transform: " + trigger);
			if(trigger != (trigger.name == "enemyVision") && trigger != (trigger.name == "EnemyZone") && trigger != (trigger.name == "PlayerLastPos") && trigger != (trigger.name == "BorderTextureVertReflection") && trigger != (trigger.name == "BorderTextureHorizReflection") && trigger != (trigger.name == "FollowUpPos") && trigger != (trigger.name == "triggerTPofobjects")) // this is so that the enemyVision trigger box is ignored, otherwise enemies would get trapped in a TP loop since the trigger box is too big, it also ignores player&enemy bullets, EnemyZone and playerLastPos
			{
				//border up tp
				if(gameObject.name == "map-border-up")
				{
					//player border up tp
					if (trigger.name == "playerTPBox") // if the collision box designed for TPing the player enters the trigger zone
						{
						GameObject.Find("spaceship-player").transform.position = new Vector3 (trigger.transform.position.x, -58.95f, trigger.transform.position.z); // teleport to -58.35f on the Y axis
						}
						
					//enemy border up tp
					if (trigger.name == "enemyTPBox")
					{
						trigger.transform.parent.position = new Vector3 (trigger.transform.position.x, -59.06f, trigger.transform.position.z);
					}
					
					//bullets border up tp
					//old code // if (trigger.name == "player-bullet(Clone)" || trigger.name == "enemy-bullet(Clone)")
					if (trigger.name == "player-bullet-tp" || trigger.name == "enemy-bullet-tp")
					{
						trigger.transform.parent.position = new Vector3 (trigger.transform.position.x, -57.82f, trigger.transform.position.z);
					}
				}
				
				//border down tp
				if(gameObject.name == "map-border-down")
				{
					//player border down tp
					if (trigger.name == "playerTPBox")
					{
					GameObject.Find("spaceship-player").transform.position = new Vector3 (trigger.transform.position.x, 57.90f, trigger.transform.position.z); // teleport to 57.3f on the Y axis
					}
					
					//enemy border down tp
					if (trigger.name == "enemyTPBox")
					{
						trigger.transform.parent.position = new Vector3 (trigger.transform.position.x, 57.97f, trigger.transform.position.z);
					}
					
					//bullets border down tp
					//old code // if (trigger.name == "player-bullet(Clone)" || trigger.name == "enemy-bullet(Clone)")
					if (trigger.name == "player-bullet-tp" || trigger.name == "enemy-bullet-tp")
					{
						trigger.transform.parent.position = new Vector3 (trigger.transform.position.x, 57.3f, trigger.transform.position.z);
					}
				}
				
				//border right tp
				if(gameObject.name == "map-border-right")
				{
					//player border right tp
					if (trigger.name == "playerTPBox")
					{
					GameObject.Find("spaceship-player").transform.position = new Vector3 (-58.81996f, trigger.transform.position.y, trigger.transform.position.z); // teleport to -54 on the X axis
					}
					
					//enemy border right tp
					if (trigger.name == "enemyTPBox")
					{
						trigger.transform.parent.position = new Vector3 (-58.814f, trigger.transform.position.y, trigger.transform.position.z);
					}
					
					//bullets border right tp
					//old code //if (trigger.name == "player-bullet(Clone)" || trigger.name == "enemy-bullet(Clone)")
					if (trigger.name == "player-bullet-tp" || trigger.name == "enemy-bullet-tp")
					{
						trigger.transform.parent.position = new Vector3 (-56, trigger.transform.position.y, trigger.transform.position.z);
					}
					
				}
				
				//border left tp
				if(gameObject.name == "map-border-left")
				{
					//player border left tp
					if (trigger.name == "playerTPBox")
					{
					GameObject.Find("spaceship-player").transform.position = new Vector3 (57.80002f, trigger.transform.position.y, trigger.transform.position.z); // teleport to 57.20001f on the X axis
					}
					
					//enemy border left tp
					if (trigger.name == "enemyTPBox")
					{
						trigger.transform.parent.position = new Vector3 (57.889f, trigger.transform.position.y, trigger.transform.position.z);
					}	
					
					//bullets border left tp
					//old code// if (trigger.name == "player-bullet(Clone)" || trigger.name == "enemy-bullet(Clone)")
					if (trigger.name == "player-bullet-tp" || trigger.name == "enemy-bullet-tp")
					{
						trigger.transform.parent.position = new Vector3 (56, trigger.transform.position.y, trigger.transform.position.z);
					}
					
				}
				
				//setting the enemy's teleporting flag to true
				if(trigger.tag == "enemyTPBox") // on Border's trigger entry, if otherObjGO has the "enemy" tag
				{
					//Debug.Log("Enemy has entered map borders" + otherObjGO.name);
					trigger.transform.parent.gameObject.GetComponent<enemyIA>().teleporting = true;
				}
				
				//setting the player's teleporting flag to true
				if(trigger.tag == "playerTPBox") // on Border's trigger entry, if otherObjGO has the "player" tag
				{
					trigger.transform.parent.gameObject.GetComponent<playerMovement>().teleporting = true;
				}
				
			}
	}

	void OnTriggerExit2D(Collider2D trigger)
	{
		if(trigger != (trigger.name == "enemyVision") && trigger != (trigger.name == "enemy-bullet(Clone)") && trigger != (trigger.name == "player-bullet(Clone)") && trigger != (trigger.name == "EnemyZone") && trigger != (trigger.name == "PlayerLastPos") && trigger != (trigger.name == "BorderTextureVertReflection") && trigger != (trigger.name == "BorderTextureHorizReflection"))
			
			//setting the enemy's teleporting flag to false
			if (trigger == (trigger.tag == "enemyTPBox"))
			{
				trigger.transform.parent.gameObject.GetComponent<enemyIA>().teleporting = false;
				//Debug.Log("Enemy has exited map borders " + trigger.name);
			}
			
			//setting the player's teleporting flag to false
			if(trigger.tag == "playerTPBox") // on Border's trigger entry, if otherObjGO has the "player" tag
			{
				trigger.transform.parent.gameObject.GetComponent<playerMovement>().teleporting = false;
				//Debug.Log("Player has exited map borders " + trigger.name);
			}
	}
}