﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class enemyIA : MonoBehaviour
{	
	public int life;
	public int shootingAngleThroughBorder = 1;
	public float enemyBulletForce = 20f; // force applied to enemy bullets
	public bool isPlayerAlive; // while player is on the scene, this bool will be truth, and the observingPlayer Vector2 will store the player's position
	public bool playerFound = false; // state to confirm if the enemy knows where the player is or not
	public bool teleporting = false; // used to correct the position of lastPlayerPos and to avoid a visual bug while teleporting (avoid the ship from looking to the updated player position, which will be behind the enemy ship, making the enemy ship go back and forth within the teleporting borders)
	public bool shootTimerRunning = false; // if too many bullets are shot, they'll collide with one another and explode on spawn, this timer prevents that from happening
	public bool inEnemyZone = false; // detects if the ship should stop moving because it's near the player enough or not
	public bool followUp; // if true, findingPlayerLastPos script will update the position of the playerLastPos gameObject, creating a "follow-up" effect (the enemy will "follow-up" +5 units on the Y axis from the position where the player was last seen), this is a different flag from playerFound as to not to trigger the other effects assigned to that flag
	public bool hasPlayerTeleported = false;
	public bool lookThroughBorder = false;
	public bool teleportSuperPower = false;
	public Collider2D enemyVision; // used to detect player within the enemyVision trigger
	public Collider2D enemyZone; // distance the enemy should be from the player 
	public Rigidbody2D rb; // accesses enemy's rigidbody2d component
	public Transform enemyFirePoint; // the point where bullets will come from (ship's front)
	public Vector2 observingPlayer; // used to store player's X and Y coordinates at all times
	public Vector2 lastPlayerPos; // last known position from player, used so that the ship can look to and move to that direction
	Vector2 currentPos;
	public GameObject playerFollower;
	public GameObject deadEffect; // particle effect for dead effect
	public GameObject enemyBulletPrefab; // load the enemyBullet prefab for shooting
	public GameObject enemyPrefab; // prefab used to load new enemies when the enemy itself dies, used for testing
	public GameObject playerLastPosGO; // to update the "isEnemyAlive" bool in the findingPlayerLastPos script of the playerLastPos gameObject
	public GameObject playerGO; // to access some player variables
	public GameObject enemyZoneGO; // this zone is as close as the enemy can get to the player, once the player is within, the enemy will stop moving forward, only aiming and shooting
	public GameObject enemySpawner; // this object will spawn a new enemy once the current one is defeated, but for that we need to change the isEnemyAlive bool within that gameObject
	public GameObject canvas; // used to store the canvas, which later will be used to update the score
	
    void Start()
    {
		life = 20;
		playerGO = GameObject.Find ("spaceship-player"); // we update this on Start because enemy prefabs will have it empty on spawn
		enemySpawner = GameObject.Find ("enemySpawner"); // we update this on Start because enemy prefabs will have it empty on spawn
		canvas = GameObject.Find("Canvas"); // finds the Canvas object, which later will be used to update the score
    }
	
	//taking damage from player-bullet
	void OnCollisionEnter2D(Collision2D collision)
	{
		if (collision.gameObject.name == "player-bullet(Clone)") // if the enemy is hitted with a bullet from the player (which will be a clone of the player-bullet prefab), enemy takes damage
			{
				life = life - 10; // -10 life per shot
				//Debug.Log("Life: " + life);
				//GameObject otherObj = collision.gameObject; // bullet collision debug, first line
				//Debug.Log("Collided with: " + otherObj); // bullet collision debug, second line				
			}
	}
	
		IEnumerator enemyBulletCoroutine() // used for timing between bullets, part 2
    {
        //Debug.Log("Started Coroutine at timestamp : " + Time.time); // Print the time of when the function is first called.
        yield return new WaitForSeconds(0.5f);  // yield on a new YieldInstruction that waits for 0.5f seconds.
		shoot(); // call shoot function to create and shoot the bullet
		shootTimerRunning = false; // return the shootTimerRunning flag back to false, so that the enemy ship can shoot again
        //Debug.Log("Finished Coroutine at timestamp : " + Time.time); //After we have waited 5 seconds print the time again.
    }
	
	void Update ()
	{
		//Teleporting Debug, uncomment to enable
		//teleportingDebug();
		
		//verifying if player is alive or not
		isPlayerAlive = (GameObject.Find ("spaceship-player")); // if the Player is on scene, this initial check in Start will set the bool isPlayerAlive to True
		
		//update enemy life/dead
		enemyDeath(); // function that triggers the enemy-death code if life <= 0
		
		//update player position
		playerPosition(); // function that updates information about the player's position
		
		//looking & shooting at player if found
		lookAndShoot();
		
		//followUp
		if (hasPlayerTeleported == true) // if the player just teleported, hasPlayerTeleported == true
		{
			followUp = true; // we want to followup the player through the portal (note that playerFound will be off at this point, so we're just moving forward with followUp in the findingPlayerLastPos script)
		}
		
	}
	
		//finding player
		void OnTriggerStay2D(Collider2D enemyVision)
		{
			{
			if (teleporting == false) // to avoid a movement bug with the enemy, if the flag "teleporting" is set to true, nothing happens, but if it's set to false, then:
			{
				//Debug.Log(enemyVision.gameObject.name + " seen");
				if (enemyVision.gameObject.name == "spaceship-player") // if the enemy sees the player,
					{
					playerFound = true;								   //player is found
					//Debug.Log("Player seen");
					}
				if (enemyVision.gameObject.name == "player-bullet(Clone)")  // if the enemy sees a player-bullet
					{
					playerFound = true;									     // player is found
					//Debug.Log("Bullet seen");
					}
			}
			}
		}
						
		//loosing player
		void OnTriggerExit2D(Collider2D enemyVision)
		{
			//Debug.Log(triggerExit.gameObject.tag + " : " + gameObject.name + " : " + Time.time);
			//if player or player bullet exits the enemyVision trigger
			if (enemyVision.gameObject.name == "spaceship-player" || enemyVision.gameObject.name == "player-bullet(Clone)")
			{
				//Debug.Log("Player lost");
				playerFound = false;
				followUp = true;
				if (teleportSuperPower == true)
				{
				transform.position = lastPlayerPos; // Super power to TP to the player's position as soon as it leaves the enemyVision trigger :D maybe a special attack of one of the ships? a ship that can't be lost? sounds interesting
				}
			}
		}			
		
		void shoot() // spawn & shoot bullets
		{
			//Debug.Log("bang");
			GameObject enemyBullet = Instantiate(enemyBulletPrefab, enemyFirePoint.position, enemyFirePoint.rotation);
			Rigidbody2D rb = enemyBullet.GetComponent<Rigidbody2D>();
			rb.AddForce(enemyFirePoint.up * enemyBulletForce, ForceMode2D.Impulse);
		}
		
		void enemyDeath()
		{
			if (life <= 0)
				{
				//Debug.Log("Enemy Destroyed");
				playerLastPosGO.GetComponent<findingPlayerLastPos>().isEnemyAlive = false; // we update the isEnemyAlive bool with the false value so that the playerLastPosGO can stop asking about the enemy position and self destroy instead
				enemyZoneGO.GetComponent<inEnemyZone>().isEnemyAlive = false; // update the isEnemyAlive var in the enemyZoneGO script
				enemySpawner.GetComponent<spawnerScript>().isEnemyAlive = false; // update the isEnemyAlive var in the enemySpawner script
				Destroy(gameObject); // destroy this gameobject
				GameObject effect = Instantiate(deadEffect, transform.position, Quaternion.identity); // dead effect particle
				Destroy(effect, 0.8f); // destroy the particle effect generated on dead
				canvas.GetComponent<scoreScript>().score = canvas.GetComponent<scoreScript>().score + 100; // accesses the <scoreScript> within the Canvas, then adds 100 to the score
				}
		}
		
		void playerPosition()
		{
			if (isPlayerAlive == true) // checks if the player is alive to interact with the playerMovement script
			{
			observingPlayer.x = playerGO.transform.position.x; //finding player: update player position X so that enemy can look in that direction later
			observingPlayer.y = playerGO.transform.position.y; //finding player: update player position Y so that enemy can look in that direction later		
				if (playerGO.GetComponent<playerMovement>().teleporting == true && playerFound == true) // check to detect the change in the player's teleporting flag and if playerFound is true, if both are true
					{
					hasPlayerTeleported = true; // this flag will be set to true (and stay like that until told otherwise, instead of updated by the update function), if this flag is true, it'll set true the followUp flag
					}
			}
		}
		
		void teleportingDebug()
		{
			if(teleporting == true)
			{
			Debug.Log("Teleporting is " + teleporting + " " + gameObject.name);
			}
		}
		
		void lookAndShoot()
		{
			if (playerFound == true && isPlayerAlive == true) //if the player is found
			{
				//looking at player directly
				if (playerGO.GetComponent<playerMovement>().teleporting == false) // this is a check to verify the player's teleporting flag, if it is true, then lastPlayerPos is not updated AND the enemy won't look at the player - this fixes a problem where if the player got teleported, most times the player-lost action wouldn't update fast enough, making the enemy will look backwards immediately after the player crossed the map border (in the direction the player was teleported to) and followUp in that direction instead of following up through the portal.
				{
					lastPlayerPos = observingPlayer; // update the lastPlayerPos variable
					
					Vector2 lookDir = lastPlayerPos - rb.position; 							    // enemy looks at the player, part 1
					float angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg - 90f; 		// enemy looks at the player, part 2
					rb.rotation = angle;														// enemy looks at the player, part 3
				}
						
				//shooting
				enemyBulletCoroutine(); //start enemyBulletCoroutine
				if (shootTimerRunning == false)
				{
					shootTimerRunning = true; // flag to confirm if the coroutine timer is running or not, enemies can't shoot while the timer is running, so this flag needs to be false before the enemy can shoot again
					StartCoroutine(enemyBulletCoroutine()); // used for time between bullets, coroutine function start
				}
				
			}
			
			//looking at player through border map
			if (lookThroughBorder == true) // this is a check to verify the player's teleporting flag, if it is true, then lastPlayerPos is not updated AND the enemy won't look at the player - this fixes a problem where if the player got teleported, most times the player-lost action wouldn't update fast enough, making the enemy will look backwards immediately after the player crossed the map border (in the direction the player was teleported to) and followUp in that direction instead of following up through the portal.
			{
				//lastPlayerPos = observingPlayer; // update the lastPlayerPos variable
				lastPlayerPos = playerFollower.transform.position; //look at playerFollower gameobject
								
				Vector2 lookDir = (lastPlayerPos - rb.position); 							    // enemy looks at playerFollower object, part 1
				float angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg - 90f;			// enemy looks at playerFollower object, part 2
				rb.rotation = angle;	
				
				//shooting
				enemyBulletCoroutine(); //start enemyBulletCoroutine
				if (shootTimerRunning == false)
				{
					shootTimerRunning = true; // flag to confirm if the coroutine timer is running or not, enemies can't shoot while the timer is running, so this flag needs to be false before the enemy can shoot again
					StartCoroutine(enemyBulletCoroutine()); // used for time between bullets, coroutine function start
				}
			}
			
			//look forward in the direction of the movement when the player isn't found
			if (playerFound == false && teleporting == false) // if player isn't found
			{
				lastPlayerPos.x = playerLastPosGO.transform.position.x; // we assign the X value of the PlayerLastPos game object to lastplayerpos.x
				lastPlayerPos.y = playerLastPosGO.transform.position.y; // we assign the Y value of the PlayerLastPos game object to lastplayerpos.y
				currentPos = new Vector2(transform.position.x, transform.position.y); // the value of the currentPos vector 2 becomes the X and Y values of the enemy's actual position (transform.position)
				
				// if the difference between lastPlayerPos and CurrentPos is greater than 2 or lower than -2 in either the X and Y axis, we'll assume the enemy is moving (because the playerLastPos object will be further away)...
				if (lastPlayerPos.x - currentPos.x > 2f || lastPlayerPos.x - currentPos.x < -2f || lastPlayerPos.y - currentPos.y > 2f || lastPlayerPos.y - currentPos.y < -2f)
				{
					//... so the enemy has to look in the direction of its movement: the playerLastPos gameobject
					Vector2 lookDir = lastPlayerPos - rb.position; 							// enemy looks at lastPlayerPos gameobject 1
					float angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg - 90f;  // enemy looks at lastPlayerPos gameobject 2
					rb.rotation = angle;  													// enemy looks at lastPlayerPos gameobject 3
				}
			}
			
		}
}