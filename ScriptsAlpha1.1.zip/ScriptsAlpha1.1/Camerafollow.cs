﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camerafollow : MonoBehaviour
{
private Transform player;
public bool isPlayerAlive; // is player alive check
 
     void Start () {
		//isPlayerAlive = (GameObject.Find ("spaceship-player")); // we get the player status: if the object can't be found, player is dead - this first check happens once in Start method - as long as the player is on the Scene, the value will be True
        player = GameObject.Find ("spaceship-player").transform; // initial search to get the player.transform data (used for getting the player coordinates)
     }
     
     void Update () {
		 
		 isPlayerAlive = (GameObject.Find ("spaceship-player")); // isPlayerAlive check on the update method
		 if(isPlayerAlive == true) // this is to avoid Unity warnings and unnecessary checks: if the player dies and Unity can't find it, we switch this variable to off and we stop trying to find and follow the player
		 {
		 player = GameObject.Find ("spaceship-player").transform; // getting player coordinates in the Update method, after confirming that isPlayerAlive is true
         Vector3 playerpos = player.position;
         playerpos.z = transform.position.z;
         transform.position = playerpos; // transform camera position to focus on the player
		 }
     }
}