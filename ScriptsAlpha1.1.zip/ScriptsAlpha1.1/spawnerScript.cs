﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawnerScript : MonoBehaviour
{
	
	public GameObject enemyObject; // object to be spawned
	public GameObject enemyHitEffect; // effect for when enemy is spawned
	public bool isEnemyAlive; // bool to confirm if enemy is alive or not
	public Collider2D spawnArea;
	public Vector2 spawnPoint;
	public Vector2 spawnerPos;
	public int Spawnradius = 50;
	//public static Vector2 insideUnitCircle;
	
    // Start is called before the first frame update
    void Start()
    {
		isEnemyAlive = true;
		spawnerPos.x = transform.position.x;
		spawnerPos.y = transform.position.y;
         //Instantiate(enemyObject);
    }

    // Update is called once per frame
    void Update()
    {
		if (isEnemyAlive == false) // if the isEnemyAlive var 
		{
			isEnemyAlive = true;
			spawnPoint = spawnerPos +  Random.insideUnitCircle * Spawnradius; // we get a random number within the spawn radius (50), we'll use that to spawn an enemy and a red particle effect
			GameObject effect = Instantiate(enemyHitEffect, spawnPoint, Quaternion.identity); // we instantiate the red particle effect
			Destroy(effect, 1f); // we destroy the effect after 1 second
			Instantiate(enemyObject, spawnPoint, Quaternion.Euler(0f, 0f, Random.Range(0.0f, 360.0f))); // we instantiate the enemy on a random spawn point with a random rotation
		}
    }
}
