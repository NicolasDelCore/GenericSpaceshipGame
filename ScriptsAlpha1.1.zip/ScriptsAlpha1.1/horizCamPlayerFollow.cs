﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class horizCamPlayerFollow : MonoBehaviour
{
	//Script for the Horizontal Cameras to follow the player on the X axis
	
	public GameObject playerGO; // used to get the isPlayerAlive bool from the playerMovement script
	public Transform playerXPos;
	public Vector3 playerXPosV3;
	public bool isPlayerAlive = true; // initializes isPlayerAlive assuming it's true, this bool will be updated by the playerMovement script if the player dies

    // Update is called once per frame
    void Update()
    {
		//isPlayerAlive = playerGO.GetComponent<playerMovement>().isPlayerAlive; // get isPlayerAlive value
		//Debug.Log("Player is alive: " + isPlayerAlive);
		
		if (isPlayerAlive == true) //(playerGO.GetComponent<playerMovement>().isPlayerAlive == true)
		{			
			playerXPosV3.x = playerXPos.position.x;
			transform.position = new Vector3 (playerXPosV3.x, transform.position.y, transform.position.z);
		} 
		
		else //if the player dies
		{
			//Debug.Log("Player is alive: " + isPlayerAlive);
			Destroy(gameObject); //this gameObject is destroyed
		}
    }
}
