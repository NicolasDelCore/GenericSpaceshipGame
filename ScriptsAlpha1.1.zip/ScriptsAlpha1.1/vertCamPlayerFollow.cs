﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class vertCamPlayerFollow : MonoBehaviour
{
	//Script for the Horizontal Cameras to follow the player on the X axis
	
	public GameObject playerGO; // used to get the isPlayerAlive bool from the playerMovement script
	public Transform playerYPos;
	public Vector3 playerYPosV3;
	public bool isPlayerAlive = true; // initializes isPlayerAlive assuming it's true, this bool will be updated by the playerMovement script if the player dies

    // Update is called once per frame
    void Update()
    {
		//isPlayerAlive = playerGO.GetComponent<playerMovement>().isPlayerAlive; // get isPlayerAlive value
		//Debug.Log("Player is alive: " + isPlayerAlive);
		
		if (isPlayerAlive == true) //(playerGO.GetComponent<playerMovement>().isPlayerAlive == true)
		{			
			playerYPosV3.y = playerYPos.position.y;
			transform.position = new Vector3 (transform.position.x, playerYPosV3.y, transform.position.z);
		}
		
		else //if the player dies
		{
			/// Debug.Log("Player is alive: " + isPlayerAlive);
			Destroy(gameObject); //this gameObject is destroyed
		}
    }
}