﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class detectingPlayerThroughBorderZoneX : MonoBehaviour
{
	// This script detects the player through the Y map borders, assigned to visionZoneX
	public bool playerFoundThroughBorder; // was the player found?
	public GameObject enemyGO; // used to alter the lookThroughBorder bool within the enemy GameObject
	public GameObject playerFollowGO; // empty GO that will indicate the enemies where to shoot to when the player is at the other side of a map border but still within the range of sight of the enemy
	public GameObject playerGO; // used to get the player's real location
	int aimingYdir; // used for the switch statement that'll mark where to position the playerFollowGO
	
	void Start()
	{
		playerGO = GameObject.Find ("spaceship-player"); // we update this on Start because enemy prefabs will have it empty on spawn
	}
	
	void Update()
	{
		if (playerFoundThroughBorder == true) // if the player is found through the border wall
		{
			// enemy looks at the player
			enemyGO.GetComponent<enemyIA>().lookThroughBorder = true;
			//reverseFollowUpBool
			//playerLastPosGO.GetComponent<findingPlayerLastPos>().reverseFollowUpBool = true; // we update the reverseFollowUpBool to be true, this will cause the enemy to move towards the border wall
		}
		
		if (enemyGO.GetComponent<enemyIA>().teleporting == true) // if the enemy is teleporting
		{
			aimingYdir = 3;
		}
	}
	
	//finding & shooting player through portal
	void OnTriggerStay2D(Collider2D enemyBorderVision)
	{
		//Debug.Log(enemyVision.gameObject.name + " seen");
		
		if (enemyBorderVision.gameObject.name == "spaceship-player") // if the enemy sees the player,
			{
			aimingY(); // executes the function that will decide where to place the playerFollowGO object
			playerFoundThroughBorder = true; //player is found
			//Debug.Log("Player seen");
			}
		
		if (enemyBorderVision.gameObject.name == "player-bullet(Clone)")  // if the enemy sees a player-bullet
			{
			playerFoundThroughBorder = true;	// player is found
			//Debug.Log("Bullet seen");
			}
	}
	
	//loosing player from the border vision
	void OnTriggerExit2D(Collider2D enemyBorderVision)
	{
		if (enemyBorderVision.gameObject.name == "spaceship-player" || enemyBorderVision.gameObject.name == "player-bullet(Clone)")
		{
			//Debug.Log("Player lost");
			playerFoundThroughBorder = false; // player no longer in sight of the borderEnemyVision object
			enemyGO.GetComponent<enemyIA>().lookThroughBorder = false; // stop looking at the player
			enemyGO.GetComponent<enemyIA>().hasPlayerTeleported = true;
		}
	}
	
	void aimingY() // function that will decide where to place the playerFollowGO object
	{
		if(enemyGO.transform.position.y > 1) // if the enemy is in the upper side of the map
		{
			aimingYdir = 1;
		}
		if(enemyGO.transform.position.y < -1)  // if the enemy is in the lower side of the map
		{
			aimingYdir = 2;
		}
		
		switch(aimingYdir)
		{
			case 1:
				playerFollowGO.transform.position = new Vector3 (playerGO.transform.position.x, playerGO.transform.position.y +117, 0); // playerFollowGO's position is modified to be in the same (X) and (Y +117) units than the player gameobject (Y + 117 is the exact spot on which the RenderTexture opposite to the real player GO will render the reflection of the player GO).
			break;
			case 2:
				playerFollowGO.transform.position = new Vector3 (playerGO.transform.position.x, playerGO.transform.position.y -117, 0); // playerFollowGO's position is modified to be in the same (X) and (Y -117) units than the player gameobject (Y - 117 is the exact spot on which the RenderTexture opposite to the real player GO will render the reflection of the player GO).
			break;
		}
	}
	
}
