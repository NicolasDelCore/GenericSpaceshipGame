using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// this script was originally based from https://www.youtube.com/watch?v=LNLVOjbrQj4&ab_channel=Brackeys

public class playerMovement : MonoBehaviour
{
	float moveSpeed = 20f; // movement speed value, used for movement
	Rigidbody2D rb; // spaceship-player's rigidbody2D, used for movement
	public Camera cam; // main camera
	Vector2 movement;
	Vector2 mousePos;
	public bool teleporting = false; // this is a flag to fix a visual bug: during teleportation from one map border to the other, the ship looks to the wrong place for a fraction of a second due to its rotation pointing to the mouse, to fix this, we disable this rotation by changing the teleporting bool to true in CollisionEnter, then we change it to false again in the CollisionExit so that rotation is recovered
	public bool isPlayerAlive = true; // bool to check whether the player is alive or not (needed by other components, such as cameras for example)
	public float life = 100f; // life points for player, starts with 100
	public ParticleSystem engineParticles1; // particle effect for when the player moves, engine 1
	public ParticleSystem engineParticles2; // particle effect for when the player moves, engine 2
	public GameObject deadEffect; // particle effect that plays on player's death
	public GameObject lifeNumber;
	public GameObject pauseMenu;
	public GameObject horizCam; // border cam horiz 
	public GameObject vertCam; // border cam vert
	public GameObject deathSoundEffect; // sound effect played on death	
	
	void Start()
	{
		rb = gameObject.GetComponent<Rigidbody2D>(); // we get this game object's rigidbody2D and store it into "rb", this will be used for moving the spaceship-player game object
		lifeNumber.GetComponent<lifeScript>().life = life; // we update the life value in the GUI
	}
	
	//Update is called once per frame, used to get input
	void Update()
	{		
		//update player life/dead
		amIAlive();
		
		// input for movement from the player
		movementInput();		
	}
	
	//FixedUpdate used to actually move the character	
	void FixedUpdate()
	{
		movementAction(); // moves the spaceship-player game object
	}
	
	//taking damage from enemy-bullet
	void OnCollisionEnter2D(Collision2D collision)
	{
		if (collision.gameObject.name == "enemy-bullet(Clone)") // if the player is hitted by an enemy-bullet (which will be a clone of the enemy-bullet prefab), player takes damage
			{
				lifeNumber.GetComponent<lifeScript>().life = life; // we update the life value in the GUI
				//Debug.Log("Life: " + life); //GameObject otherObj = collision.gameObject; // -bullet collision debug, first line //Debug.Log("Collided with: " + otherObj); // -bullet collision debug, second line
			}
	}
	
	void movementInput() // takes input from the player
	{
		movement.x = Input.GetAxisRaw("Horizontal"); // X axis movement
		movement.y = Input.GetAxisRaw("Vertical");	// Y axis movement	
		mousePos = cam.ScreenToWorldPoint(Input.mousePosition); // ship pointing to mouse
		amIMoving(); // calls a function to check whether the player is moving or not, used for particle-effects
	}
	
	void movementAction() // moves the spaceship-player game object
	{
		if (teleporting == false) 
		{
			rb.MovePosition(rb.position + movement * moveSpeed * Time.fixedDeltaTime); //movement
			//spaceship-player gameObject points to the mouse
			Vector2 lookDir = mousePos - rb.position;
			float angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg - 90f;
			rb.rotation = angle;
		}
	}
	
	void amIAlive()
	{
		if (life <= 0)
		{
			horizCam.GetComponent<horizCamPlayerFollow>().isPlayerAlive = false; // border cam horiz to stop following
			vertCam.GetComponent<vertCamPlayerFollow>().isPlayerAlive = false; // border cam vert to stop following
			GameObject deathSFX = Instantiate(deathSoundEffect, transform.position, Quaternion.identity); // we instantiate the explosion sound effect on enemy dead
			Destroy(gameObject);
			GameObject effect = Instantiate(deadEffect, transform.position, Quaternion.identity); // dead effect particle
			Destroy(effect, 0.8f);
			pauseMenu.GetComponent<pauseMenu>().isPlayerAlive = false; // this shows the death screen
		}
	}
	
	void amIMoving()
	{
		if (movement.x != 0 || movement.y != 0) // if the player is moving or trying to (if horizontal or vertical input is detected)
		{
			engineParticles1.Play(); // reproduce particle effect, engine 1
			engineParticles2.Play(); // reproduce particle effect, engine 2
		}
		else // if there's no movement (movement.y and movement.x will are equal to 0)
		{
			engineParticles1.Stop(); // stop particle effect, engine 1
			engineParticles2.Stop(); // stop particle effect, engine 2
		}
	}
}