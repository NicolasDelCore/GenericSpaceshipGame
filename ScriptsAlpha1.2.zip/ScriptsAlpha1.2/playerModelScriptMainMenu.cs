﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class playerModelScriptMainMenu : MonoBehaviour
{
    // Start is called before the first frame update
	
	Rigidbody2D rb; // spaceship-player's rigidbody2D
	Vector2 mousePos; // stores mouse position
	
    void Start()
    {
        rb = gameObject.GetComponent<Rigidbody2D>(); // we get this game object's rigidbody2D and store it into "rb", this will be used for moving the spaceship-player game object
    }

    // Update is called once per frame
    void Update()
    {
		mousePos = Input.mousePosition;
		//mousePos = cam.ScreenToWorldPoint(Input.mousePosition); // get mouse position
		// ship points to mouse
		Vector2 lookDir = mousePos - rb.position;
		float angle = Mathf.Atan2(lookDir.y, lookDir.x) * Mathf.Rad2Deg - 90f;
		rb.rotation = angle;
        
    }
}