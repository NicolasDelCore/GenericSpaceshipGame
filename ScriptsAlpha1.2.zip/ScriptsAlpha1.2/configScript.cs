﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI; // GUI interactions
using System.IO; // to save/load settings

public class configScript : MonoBehaviour
{
	
	public Toggle fullScreenToggle; // fullScreen toggle
	public Toggle globalSoundToggle; // mute / unmute toggle
	public Toggle radarToggle; // to change the radar toggle
	public Slider musicSlider; // music slider
	public AudioSource musicSource; // source for music
	public Slider sfxSlider;// sound effects slider
	public Dropdown resolutionDropdown; // dropdown with resolutions
	public Resolution[] resolutions; // array 
	public GameSettings gameSettings; // reference to our custom GameSettings class
	public int currentResolutionIndex;
	
	void Start()
	{
		//we get the resolutions & if there's no resolution loaded, we load one by default based on the monitor
		GetResolutions();
	}
	
	void OnEnable()
	{
		gameSettings = new GameSettings(); // initialize new instance of GameSettings
		
		resolutions = Screen.resolutions; // get screen resolutions to store in our resolutions array
		
		//call methods through onValueChange events when a change is done
		fullScreenToggle.onValueChanged.AddListener(delegate { OnFullScreenToggle(); }); // we subscribe the method to the event, the method fullScreenToggle will occur when the event onValueChanged occurs
		resolutionDropdown.onValueChanged.AddListener(delegate { OnResolutionChange(); });
		musicSlider.onValueChanged.AddListener(delegate { OnMusicSliderChange(); });
		sfxSlider.onValueChanged.AddListener(delegate { OnSfxSliderChange(); });
		
		//we get the resolutions & if there's no resolution loaded, we load one by default based on the monitor
		GetResolutions();
		
		// if there's a previous config already saved, load that, otherwise load the default values
		loadConfigOrDefaults();
		
		doWePlayMusic();
	}

	public void OnFullScreenToggle()
	{	
		fullScreenToggle.GetComponent<toggleScript>().toggleComponentBool = fullScreenToggle.isOn; // updates the toggle graphic, changes the toggleComponentBool within the toggleScript of fullScreenToggle
		gameSettings.fullScreen = Screen.fullScreen = fullScreenToggle.isOn;
		saveConfig();
	}
	
	void GetResolutions()
	{
		// get resolutions for the dropdown menu & select the currently used resolution
		resolutionDropdown.ClearOptions();
		List<string> resOptions = new List<string>();
		
		// get resolutions
		int currentResolutionIndex = 0;
		for (int i = 0; i < resolutions.Length; i++)
		{
			string resOption = resolutions[i].ToString(); //resolutions[i].width + " x " + resolutions[i].height;
			resOptions.Add(resOption);
			
			//if (resolutions[i].width == Screen.currentResolution.width && resolutions[i].height == Screen.currentResolution.height)
			if (resolutions[i].width == Screen.width && resolutions[i].height == Screen.height)
			{
				currentResolutionIndex = i;
			}			
		}
		
		// put resolution options in the dropdown
		resolutionDropdown.AddOptions(resOptions);
		
		// if there's no config file already saved, we force the resolution by default to be selected
		if (File.Exists(Application.persistentDataPath + "/GenericSpaceshipGameSettings.json") == false)
		{
			resolutionDropdown.value = currentResolutionIndex;
		}
		
		// refresh shown value for resolution dropdown
		resolutionDropdown.RefreshShownValue();
		
	}
	
	public void OnResolutionChange()
	{
		Screen.SetResolution(resolutions[resolutionDropdown.value].width, resolutions[resolutionDropdown.value].height, Screen.fullScreen); // we change the resolution without modifying the fullscreen
		gameSettings.resolutionIndex = resolutionDropdown.value;
		saveConfig();
	}
	
	public void OnGlobalSoundToggle()
	{
		globalSoundToggle.GetComponent<toggleScript>().toggleComponentBool = !globalSoundToggle.GetComponent<toggleScript>().toggleComponentBool; // updates the toggle graphic, changes the toggleComponentBool within the toggleScript of globalSoundToggle
		gameSettings.globalSound = globalSoundToggle.isOn;
		
		doWePlayMusic(); // function that decides whether music should be played or not
		
		saveConfig(); // save config
	}
	
	void doWePlayMusic()
	{
		if (globalSoundToggle.isOn == false) // if toggle is off
		{
			musicSource.Stop(); // don't play music
		}
		
		if (globalSoundToggle.isOn == true) // if toggle is on
		{
			musicSource.Play(); // play music
		}
	}
	
	public void OnRadarToggle() // enables or disables radar, only from Main Menu
	{
		//radarToggleBool = !radarToggleBool; // change radarToggleBool
		radarToggle.GetComponent<toggleScript>().toggleComponentBool = !radarToggle.GetComponent<toggleScript>().toggleComponentBool; // updates the toggle graphic, change radarToggle's toggleComponentBool
		gameSettings.radarIsOn = radarToggle.isOn; // we turn the radar on/off in the gameSettings
		//Debug.Log(gameSettings.radarIsOn);
		saveConfig();
	}
	
	public void OnMusicSliderChange()
	{	
		musicSource.volume = gameSettings.musicVolume = musicSlider.value;
		saveConfig();
	}
	
	public void OnSfxSliderChange()
	{
		gameSettings.effectsVolume = sfxSlider.value;
		saveConfig();
	}
	
	public void saveConfig()
	{
		string jsonData = JsonUtility.ToJson(gameSettings, true);
		File.WriteAllText(Application.persistentDataPath + "/GenericSpaceshipGameSettings.json", jsonData);
	}
	
	void loadConfigOrDefaults()
	{
		if (File.Exists(Application.persistentDataPath + "/GenericSpaceshipGameSettings.json") == true) // if there's a previous config already saved
        {
           loadConfig(); // load the config file
        }
	}
	
	public void loadConfig()
	{
		// load file with saved settings
		gameSettings = JsonUtility.FromJson<GameSettings>(File.ReadAllText(Application.persistentDataPath + "/GenericSpaceshipGameSettings.json"));
		
		//adjust settings to the loaded values
		radarToggle.isOn = gameSettings.radarIsOn;
		gameSettings.fullScreen = Screen.fullScreen;
		fullScreenToggle.isOn = Screen.fullScreen;
		globalSoundToggle.isOn = gameSettings.globalSound;
		resolutionDropdown.value = gameSettings.resolutionIndex;
		musicSlider.value = gameSettings.musicVolume;
		sfxSlider.value = gameSettings.effectsVolume;		
		doWePlayMusic(); // function that decides whether music should be played or not
		resolutionDropdown.RefreshShownValue();
	}	
}
