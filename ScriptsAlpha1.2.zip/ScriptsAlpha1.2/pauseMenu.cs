﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class pauseMenu : MonoBehaviour
{
	public bool isPlayerAlive = true; // playerMovement script will update this value to "False" if player dies
    public static bool gameIsPaused = false;
	//bool fullScreenBool;
	bool gameOptionsOn = false;	
	public GameObject pauseMenuUI;
	public GameObject optionsUI;
	public GameObject deathScreenUI;
	public GameObject gameUI;
	public GameObject fullScreenToggle;
	
    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.Escape)) // when pressing the Esc key
		{
			if(gameIsPaused && gameOptionsOn == false) // if we're on the Pause menu but we're not in the Options menu
			{
				Resume(); // we can go back to the game
			}
			else // otherwise
			{
				Pause(); // we go to the Pause menu (if we're playing or if we're in the Options menu)
			}
		}
		
		if(isPlayerAlive == false) // if player dies, the isPlayerAlive bool gets updated by the playerMovement script, and we call the PlayerDead() function
		{
			PlayerDead();
		}
    }
	
	public void Resume ()
	{
		pauseMenuUI.SetActive(false);
		Time.timeScale = 1f;
		gameIsPaused = false;
	}
	
	public void Pause ()
	{
		pauseMenuUI.SetActive(true);
		optionsUI.SetActive(false); // if we return to the Pause menu from Options, this disables the Options menu
		gameOptionsOn = false; // we disable the gameOptionsOn bool
		Time.timeScale = 0f;
		gameIsPaused = true;
	}
	
	public void LoadMenu()
	{
		gameIsPaused = false;
		isPlayerAlive = true;
		Time.timeScale = 1f;
		SceneManager.LoadScene("mainMenu");
	}
	
	public void Options()
	{
		gameOptionsOn = true;
		pauseMenuUI.SetActive(false);
		optionsUI.SetActive(true);
		Time.timeScale = 0f;
		gameIsPaused = true;
	}
	
	public void QuitGame()
	{
		Application.Quit();
	}
	
	public void PlayerDead()
	{
		gameUI.SetActive(false);
		deathScreenUI.SetActive(true);
		Time.timeScale = 0f;
		gameIsPaused = true;
	}
	
	public void Restart()
	{
		gameUI.SetActive(true);
		gameIsPaused = false;
		isPlayerAlive = true;
		Time.timeScale = 1f;
		SceneManager.LoadScene("infiniteLevel");
	}
}
