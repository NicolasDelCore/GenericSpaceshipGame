﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class loneCornerCam : MonoBehaviour
{
	
	//Positioning of the lone camera and the lone reflected texture
	//Lone camera will always be in the "empty" corner (it'll be the corner without cameras when the player itself is in a corner)
	//Note: the reflected texture will always be the in the opposite corner as the lone camera, so I'll just refer to the position of the camera instead
	
	public int camPos;
	public Transform loneCam;
	public Transform lonePlane;
	public GameObject player; // to get the player's position & live/dead status
	
    // Update is called once per frame
    void Update()
    {
		if (player.GetComponent<playerMovement>().life > 0) // if player is alive
		{
			if(player.transform.position.x < -1 && player.transform.position.y < -1) // if the player is in the lower left part of the map
			{
				camPos = 1; //  the camera's position should be Case 1 (upper right corner)
			}
			if(player.transform.position.x < -1 && player.transform.position.y > 1) // if the player is in the upper left part of the map
			{
				camPos = 2;  //  the camera's position should be Case 2 (lower right corner)
			}
			if(player.transform.position.x > 1 && player.transform.position.y > 1) // if the player is in the upper right part of the map
			{
				camPos = 3;  //  the camera's position should be Case 3 (lower left corner)
			}
			if(player.transform.position.x > 1 && player.transform.position.y < -1) // if the player is in the lower right part of the map
			{
				camPos = 4;  //  the camera's position should be Case 4  (upper left corner)
			}
			
			//the loneCam and lonePlane objects are fixed to 4 possible positions: these objects will always occupy corners opposite to each other
			switch (camPos)
			{
				case 1: // loneCam in the upper right corner, lonePlane in the opposite corner
					loneCam.transform.localPosition = new Vector3 (-43.8f, 19.5f, -8.4f);
					lonePlane.transform.localPosition = new Vector3 (73f, -96.73f, 0f);
				break;
				case 2: // loneCam in the lower right corner, lonePlane in the opposite corner
					loneCam.transform.localPosition = new Vector3 (45.85f, 19.5f, -8.4f);
					lonePlane.transform.localPosition = new Vector3 (-70.8f, -96.7f, 0f);
				break;
				case 3: // loneCam in the lower left corner, lonePlane in the opposite corner
					loneCam.transform.localPosition = new Vector3 (45.9f, -70.3f, -8.4f);
					lonePlane.transform.localPosition = new Vector3 (-70.8f, 46.3f, 0f);
				break;
				case 4: // loneCam in the upper left corner, lonePlane in the opposite corner
					loneCam.transform.localPosition = new Vector3 (-44f, -70.3f, -8.4f);
					lonePlane.transform.localPosition = new Vector3 (73f, 46.3f, 0f);
				break;
			}
		}
		else //if player is dead
		{
			Destroy(gameObject); //destroy this gameobject
		}
    }
}
