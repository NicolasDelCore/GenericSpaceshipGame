﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// this script handles the score system

public class scoreScript : MonoBehaviour
{
	//score vars
	public int score = 0; // score int, it's updated from the enemyIA script - each time an enemy dies = +100 points
	public Text scoreNumberGameUI; // score number text during gameplay
	public Text scoreNumberDeathScreen; // score number in death screen

	
    void Update()
    {
		//Debug.Log("Score: " + score);
		scoreNumberGameUI.text = score.ToString(); // updates the score text to match the score int	in the Game UI	
		scoreNumberDeathScreen.text = score.ToString(); // updates the score text to match the score int in the Death Screen
    }
}