﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class mainMenu : MonoBehaviour
{
	public GameObject mainMenuUI;
	public GameObject optionsMenuUI;
	
	public void playGame()
	{
		SceneManager.LoadScene("infiniteLevel"); // starts the game's infinite level
	}
	
	public void quitGame()
	{
		Application.Quit(); // quits the game
	}
	
	public void options()
	{
		mainMenuUI.SetActive(false); // disables main menu
		optionsMenuUI.SetActive(true); // enables options menu
	}
	
	public void backMainMenu()
	{
		optionsMenuUI.SetActive(false); // disables options menu
		mainMenuUI.SetActive(true); // enables main menu
	}
}