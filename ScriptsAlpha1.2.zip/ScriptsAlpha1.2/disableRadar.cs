﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class disableRadar : MonoBehaviour
{
	public GameObject radarGO; // radar game object
	public Canvas canv; // holds the config script
	
    // Start is called before the first frame update
    void Start()
    {
		if (canv.GetComponent<configScript>().gameSettings.radarIsOn == true) // if radar is on
		{
			radarGO.SetActive(true); // activate gameobject radar
		}
		
		if (canv.GetComponent<configScript>().gameSettings.radarIsOn == false) // if radar is off
		{
			radarGO.SetActive(false); // disable gameobject radar
		}
    }

    // Update is called once per frame
    /*void Update()
    {
        
    }*/
}
