﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class borderEnemyVision : MonoBehaviour
{
	// This script takes care of moving and (if necessary) destroying the borderEnemyVision object (which contains the visionZoneX and visionZoneY childs)
	public GameObject enemyBeingFollowed; // enemy that the borderEnemyVision object will be following
	public GameObject visionZoneXFollow;  // visionZoneX GO will follow the enemy in X axis
	public GameObject visionZoneYFollow;  // visionZoneY GO will follow the enemy in Y axis
	public GameObject visionZoneLoneCorner; // visionZoneLoneCorner GO will possitionate in the corner opposite to the enemy
	public int visionZonePosX; // changes visionZoneX to the opposite wall of the map
	public int visionZonePosY; // changes visionZoneY to the opposite wall of the map
	public int visionZoneLoneCornerPos; // changes visionZoneLoneCorner to the opposite corner of the map
	
	void Start()
	{
		transform.SetParent(null); // we unparent the borderEnemyVision GameObject from the enemy, so that it can work independantly from the enemyVision trigger
	}
	
    // Update is called once per frame
    void Update()
    {
	isMyEnemyDeath();
	myPosition();     
    }
	
	//modifies the position that this object will take with respect to the enemy it's following
	void myPosition()
	{	
		//enemy is followed through the map borders in X (visionZoneXFollow) and Y (visionZoneYFollow)
		visionZoneXFollow.transform.position = new Vector3 (enemyBeingFollowed.transform.position.x, visionZoneXFollow.transform.position.y, visionZoneXFollow.transform.position.z);
		visionZoneYFollow.transform.position = new Vector3 (visionZoneYFollow.transform.position.x, enemyBeingFollowed.transform.position.y, visionZoneYFollow.transform.position.z);
		
		//X movement
		if(enemyBeingFollowed.transform.position.y > 1) // if the enemy is in the upper part of the map
		{
			visionZonePosX = 1; // visionZonePosX is in the lower zone
		}
		if(enemyBeingFollowed.transform.position.y < -1) // if the enemy is in the lower part of the map
		{
			visionZonePosX = 2; // visionZonePosX is in the upper zone
		}
		
		//Y movement
		if(enemyBeingFollowed.transform.position.x > 1) // if the enemy is in the right part of the map
		{
			visionZonePosY = 1;   // visionZonePosY is in the left zone
		}
		if(enemyBeingFollowed.transform.position.x < -1) // if the enemy is in the left part of the map
		{
			visionZonePosY = 2;  // visionZonePosY is in the right zone
		}
		
		//Corner movement
		if(enemyBeingFollowed.transform.position.x > 1  && enemyBeingFollowed.transform.position.y > 1) // if the enemy is in the upper right part of the map
		{
			visionZoneLoneCornerPos = 1;
		}
		if(enemyBeingFollowed.transform.position.x < -1 && enemyBeingFollowed.transform.position.y > 1) // if the enemy is in the upper left part of the map
		{
			visionZoneLoneCornerPos = 2;
		}
		if(enemyBeingFollowed.transform.position.x < -1 && enemyBeingFollowed.transform.position.y < -1) // if the enemy is in the lower left part of the map
		{
			visionZoneLoneCornerPos = 3;
		}
		if(enemyBeingFollowed.transform.position.x > 1 && enemyBeingFollowed.transform.position.y < -1) // if the enemy is in the lower right part of the map
		{
			visionZoneLoneCornerPos = 4;
		}
		
		
		switch (visionZonePosX) //visionZoneXFollow position changes to the opposite border wall
		{
			case 1: // visionZoneXFollow in left side
				visionZoneXFollow.transform.position = new Vector3 (enemyBeingFollowed.transform.position.x, -54f, visionZoneXFollow.transform.position.z);
			break;
			case 2: // visionZoneXFollow in right side
				visionZoneXFollow.transform.position = new Vector3 (enemyBeingFollowed.transform.position.x, 54f, visionZoneXFollow.transform.position.z);
			break;
		}
			
		switch (visionZonePosY) //visionZoneYFollow position changes to the opposite border wall
		{
			case 1: // visionZoneYFollow in lower side
				visionZoneYFollow.transform.position = new Vector3 (-53.8f, visionZoneYFollow.transform.position.y, visionZoneYFollow.transform.position.z);
			break;
			case 2: // visionZoneYFollow in upper side
				visionZoneYFollow.transform.position = new Vector3 (53.8f, visionZoneYFollow.transform.position.y, visionZoneYFollow.transform.position.z);
			break;
		}
		
		switch (visionZoneLoneCornerPos)
		{
			case 1: // visionZoneLoneCorner is in the lower left part of the map
			visionZoneLoneCorner.transform.position = new Vector3 (-53.8f, -54f, visionZoneLoneCorner.transform.position.z);
			break;
			case 2: // visionZoneLoneCorner is in the lower right part of the map
			visionZoneLoneCorner.transform.position = new Vector3 (53.8f, -54f, visionZoneLoneCorner.transform.position.z);
			break;
			case 3: // visionZoneLoneCorner is in the upper right part of the map
			visionZoneLoneCorner.transform.position = new Vector3 (53.8f, 54f, visionZoneLoneCorner.transform.position.z);
			break;
			case 4: // visionZoneLoneCorner is in the upper left part of the map
			visionZoneLoneCorner.transform.position = new Vector3 (-53.8f, 54f, visionZoneLoneCorner.transform.position.z);
			break;
		}
		
	}
	
	void isMyEnemyDeath()
	{
		if (enemyBeingFollowed.GetComponent<enemyIA>().life <= 0) // if the enemy this object follows is death
		{
		Destroy(gameObject); // destroy this gameobject
		}
	}
}
