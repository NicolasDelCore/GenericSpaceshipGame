﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class explosionSoundScript : MonoBehaviour
{
	private AudioSource audioSource; // source of sound
	public AudioClip[] explosionSound; // array of sounds for laser bullets
	private AudioClip explosionClip; // audio clip to be reproduced when explosion spawns
	public GameObject canvas; // access the config script within our Canvas gameobject to get the value for the SFX volume
	private float sfxVolume; // float that stores the volume to be applied for sfx (explosion sound volume)

    // Start is called before the first frame update
    void Start()
    {
		canvas = GameObject.Find("Canvas"); // get the canvas object, which contains the config script, and store it in a GameObject type variable "canvas"
		sfxVolume = canvas.GetComponent<configScript>().sfxSlider.value; // apply the volume defined in canvas' sfxSlider to the float sfxVolume		
		audioSource = gameObject.GetComponent<AudioSource>(); // get audio source component for the explosion object
		PlayRandomExplosion(); // call the function that plays a random laser sound
	}
	
	void PlayRandomExplosion()
	{
		if(canvas.GetComponent<configScript>().globalSoundToggle.isOn == true)
		{
			audioSource.volume = sfxVolume;
			//Debug.Log("configured vol " + sfxVolume); // debug configured volume for SFX
			//Debug.Log("explosion vol " + audioSource.volume); // debug explosion's true volume
			int index = Random.Range(0, 4); // gets a number between 0 and 4
			//Debug.Log(index); // debug for random number chosen in
			explosionClip = explosionSound[index]; // select the shoot sound in the array, based on the random number
			audioSource.clip = explosionClip; // assigns clip to the audio source
			audioSource.Play(); // plays the audio source
			Destroy(gameObject, audioSource.clip.length);
		}
	}
}
