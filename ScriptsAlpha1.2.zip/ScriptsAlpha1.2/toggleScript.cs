﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class toggleScript : MonoBehaviour
{
	public GameObject ToggleSelectorGO; // square-sprite that shows the selected option
	public bool toggleComponentBool; // this component will be updated from outside when the toggle is activated
	
    // Start is called before the first frame update
    void Start()
    {
        toggleComponentBool = gameObject.GetComponent<Toggle>().isOn; // on intialization, put the selector sprite in the correct position
    }

    // Update is called once per frame
    void Update()
    {
       if (toggleComponentBool) // if toggleComponentBool is true
		{
			ToggleSelectorGO.transform.localPosition = new Vector3(-12f, 0, 0); // move the selector-sprite's localPosition to -12f
		}
		if (toggleComponentBool == false)  // if toggleComponentBool is false
		{
			ToggleSelectorGO.transform.localPosition = new Vector3(12f, 0, 0);  // move the selector-sprite's localPosition to 12f
		}
    }
}
