﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class inEnemyZone : MonoBehaviour
{
	public GameObject enemyObject;
	public Transform enemyObjectTransform;
	public Collider2D enemyZone;
	public bool isEnemyAlive;
	
    // Start is called before the first frame update
    void Start()
    {
		isEnemyAlive = true;
        transform.SetParent(null); //we need to unparent this enemyZone gameObject from the enemy, otherwise it'll generate activation problems with the enemyVision trigger
		enemyObjectTransform = enemyObject.transform; // but we still want this gameObject to be at the same position as the enemy at all times, so we need the enemy transform
    }
	
	void Update()
	{
	if (isEnemyAlive == true) // isEnemyAlive check, if so:
			{
			transform.position = enemyObjectTransform.position; // instruction for the enemyZone gameobject to have the same position as the enemy object, Update method
			}
	if (isEnemyAlive == false) // if the enemy gameObject is destroyed (when its life reaches 0 or less), before destroying itself it'll update the isEnemyAlive bool of this script, setting it to false
			{
				Destroy(gameObject);
			}
	}
	
	void OnTriggerEnter2D(Collider2D enemyZone)
	{
		if (isEnemyAlive == true) // isEnemyAlive check, if so:
		{
			if(enemyZone.gameObject.name == "spaceship-player") // if the player is enters this zone
			{
				enemyObject.GetComponent<enemyIA>().inEnemyZone = true; // we turn the inEnemyZone flag on within the enemy's IA script - this will update the playerLastPos gameobject position in the findingPlayerLastPos script to be the same pos as the enemy (so the enemy stops moving at that point)
				//Debug.Log(triggerEnter.gameObject.tag + " : " + gameObject.name + " : " + Time.time);
			}
		}
	}
	
		void OnTriggerExit2D(Collider2D enemyZone)
	{
		if (isEnemyAlive == true) // isEnemyAlive check, if so:
		{
			if(enemyZone.gameObject.name == "spaceship-player") // if the player exits this zone
			{
				enemyObject.GetComponent<enemyIA>().inEnemyZone = false; // we turn the inEnemyZone flag off within the enemy's IA script
				//Debug.Log(triggerEnter.gameObject.tag + " : " + gameObject.name + " : " + Time.time);
			}
		}
	}	

}
