﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class lifeScript : MonoBehaviour
{
	//score vars
	public float life; // player life, it's updated from the playerMovement script at Start() and each time the player receives damage in Update()
	public Text lifeNumber; // score number text
	
    void Update()
    {
		lifeNumber.text = life.ToString(); // updates the lifeNumber text to match the life float value	
    }
}
