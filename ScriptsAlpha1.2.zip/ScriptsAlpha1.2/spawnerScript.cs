﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class spawnerScript : MonoBehaviour
{
	
	public GameObject normalEnemy; // object to be spawned
	public GameObject trackerEnemy; // object to be spawned
	public GameObject captainEnemy; // object to be spawned
	public GameObject spawnEffect; // effect for when enemy is spawned
	public bool isEnemyAlive = true; // bool to confirm if enemy is alive or not
	public bool wasTrackerEnemy = false; // bool that confirms if the enemy that just died was of the Tracker type or not
	public bool wasCaptainEnemy = false; // bool that confirms if the enemy that just died was of the Captain type or not
	public Collider2D spawnArea;
	public Vector2 spawnPoint;
	public Vector2 spawnerPos;
	public int Spawnradius = 50;
	//public static Vector2 insideUnitCircle;
	
    // Start is called before the first frame update
    void Start()
    {
		isEnemyAlive = true;
		spawnerPos.x = transform.position.x;
		spawnerPos.y = transform.position.y;
    }

    // Update is called once per frame
    void Update()
    {
		if (isEnemyAlive == false) // if the isEnemyAlive value changes to False 
		{
			//if the enemy who died was of type Tracker
			if (wasTrackerEnemy == true)
			{
				//Debug.Log("Tracker died");
				isEnemyAlive = true;
				wasTrackerEnemy = false;
				spawnPoint = spawnerPos +  Random.insideUnitCircle * Spawnradius; // we get a random number within the spawn radius (50), we'll use that to spawn an enemy and a red particle effect
				GameObject effect = Instantiate(spawnEffect, spawnPoint, Quaternion.identity); // we instantiate the red particle effect
				Destroy(effect, 1f); // we destroy the effect after 1 second
				Instantiate(trackerEnemy, spawnPoint, Quaternion.Euler(0f, 0f, Random.Range(0.0f, 360.0f))); // we instantiate the enemy on a random spawn point with a random rotation
			}
			
			//if it was not of type tracker
			else
			{	
				//if the enemy who died was of type Captain
				if (wasCaptainEnemy == true)
				{
					//Debug.Log("Captain died");
					isEnemyAlive = true;
					wasCaptainEnemy = false;
					spawnPoint = spawnerPos +  Random.insideUnitCircle * Spawnradius; // we get a random number within the spawn radius (50), we'll use that to spawn an enemy and a red particle effect
					GameObject effect = Instantiate(spawnEffect, spawnPoint, Quaternion.identity); // we instantiate the red particle effect
					Destroy(effect, 1f); // we destroy the effect after 1 second
					Instantiate(captainEnemy, spawnPoint, Quaternion.Euler(0f, 0f, Random.Range(0.0f, 360.0f))); // we instantiate the enemy on a random spawn point with a random rotation
				}
			
				//if the enemy who died was of normal type
				else
				{
					//Debug.Log("Normal died");
					isEnemyAlive = true;
					spawnPoint = spawnerPos +  Random.insideUnitCircle * Spawnradius; // we get a random number within the spawn radius (50), we'll use that to spawn an enemy and a red particle effect
					GameObject effect = Instantiate(spawnEffect, spawnPoint, Quaternion.identity); // we instantiate the red particle effect
					Destroy(effect, 1f); // we destroy the effect after 1 second
					Instantiate(normalEnemy, spawnPoint, Quaternion.Euler(0f, 0f, Random.Range(0.0f, 360.0f))); // we instantiate the enemy on a random spawn point with a random rotation
				}
			}
		}
    }
}
