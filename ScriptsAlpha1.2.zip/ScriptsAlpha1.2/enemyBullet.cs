﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class enemyBullet : MonoBehaviour
{
	//bullet objects will destroy themselves with collisions, OR, will desttroy themselves if nothing was hitted after 1 second (using the timer bulletExpirationTimer)
	public GameObject player;
	public GameObject enemyHitEffect; // particle effect for bullet destruction
	float enemyBulletExpirationTimer = 0f; //bulletExpirationTimer starts at 0
	private bool collisionDetected = false; // bool to avoid double-collision detection (double damage), which would be an issue if the player's collision box is touching the enemy's collision box
	private AudioSource audioSource; // source of sound
	public AudioClip[] shootSound; // array of sounds for laser bullets
	private AudioClip shootClip; // audio clip to be reproduced when bullet spawns
	public GameObject canvas; // access the config script within our Canvas gameobject to get the value for the SFX volume
	private float sfxVolume; // float that stores the volume to be applied for sfx (bullet sound volume)
	
	void Start()
	{
		canvas = GameObject.Find("Canvas"); // get the canvas object, which contains the config script, and store it in a GameObject type variable "canvas"
		sfxVolume = canvas.GetComponent<configScript>().sfxSlider.value; // apply the volume defined in canvas' sfxSlider to the float sfxVolume		
		audioSource = gameObject.GetComponent<AudioSource>(); // get audio source component for the bullet object
		PlayRandomLaser(); // call the function that plays a random laser sound
	}
	
	void OnCollisionEnter2D(Collision2D collision)
	{
		//GameObject otherObj = collision.gameObject; // bullet collision debug, first line
		//Debug.Log("Collided with: " + otherObj); // bullet collision debug, second line
		GameObject effect = Instantiate(enemyHitEffect, transform.position, Quaternion.identity);
		Destroy(effect, 0.1f);
		Destroy(gameObject);
		
		if (collision.gameObject.name == "spaceship-player") // if the object collided with is the player
		{
			if (collisionDetected == false) // if there hasn't been a collision yet, collisionDetected will be false, and if that's the case
			{
				collisionDetected = true; // collisionDetected changed to True to avoid detecting more than one collision
				player = GameObject.Find("spaceship-player"); // store player-gameObject in "player"
				player.GetComponent<playerMovement>().life = player.GetComponent<playerMovement>().life - 10; // player -10 HP
			}
		}
		
	}
	
	void Update()
	{
		enemyBulletExpirationTimer += Time.deltaTime; //add time to bulletExpirationTimer
		if (enemyBulletExpirationTimer >= 1) //if bulletExpirationTimer is greater or equal to 1 sec
		{
			enemyBulletExpires(); // call function bulletExpires
		}
	}
	
	void enemyBulletExpires()
	{
		GameObject effect = Instantiate(enemyHitEffect, transform.position, Quaternion.identity);
		Destroy(effect, 0.1f);
		Destroy(gameObject);
	}
	
	void PlayRandomLaser()
	{
		if(canvas.GetComponent<configScript>().globalSoundToggle.isOn == true)
		{
			audioSource.volume = sfxVolume; // use the sfxVolume value but lower it down a bit so that other things can be heard better (like explosions)
			//Debug.Log("configured vol " + sfxVolume); // debug configured volume for SFX
			//Debug.Log("bullet vol " + audioSource.volume); // debug bullet's true volume
			int index = Random.Range(0, 3); // gets a number between 0 and 2
			//Debug.Log(index); // debug for random number chosen in
			shootClip = shootSound[index]; // select the shoot sound in the array, based on the random number
			audioSource.clip = shootClip; // assigns clip to the audio source
			audioSource.Play(); // plays the audio source
		}
	}
	
}