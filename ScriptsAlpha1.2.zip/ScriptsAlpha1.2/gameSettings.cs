﻿public class GameSettings
{
	public bool fullScreen;
	public bool globalSound = true; // default true
	public bool radarIsOn = true; // default true
	public int resolutionIndex;
	public float musicVolume = 0.3f; // default 0.5f
	public float effectsVolume = 0.7f; // default 0.5f
}